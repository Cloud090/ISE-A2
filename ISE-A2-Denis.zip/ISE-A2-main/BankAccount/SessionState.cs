﻿
namespace BankApp
{
    public enum SessionState
    {
        Default = 0,
        Authenticated = 1,
        SessionEnded = 2,
        ExistingUser = 3
    }
}
